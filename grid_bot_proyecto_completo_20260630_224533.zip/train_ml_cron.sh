#!/bin/bash
# train_ml_cron.sh — Entrenamiento automático de modelos ML para Grid Bot
# Ejecutar desde cron cada 6 horas (o frecuencia deseada)
# Cron example: 0 */6 * * * /bin/bash /home/erika/web/binance.gregorbritez.cat/public_html/train_ml_cron.sh

set -euo pipefail  # Salir ante error, variables no definidas, pipes fallidos

# ================= CONFIGURACIÓN =================
BASE_DIR="/home/erika/web/binance.gregorbritez.cat/public_html"
cd "$BASE_DIR"

# Logs y control
LOGFILE="train_ml_cron.log"
LOCKFILE="train_ml_cron.lock"
MAX_LOG_SIZE=$((10 * 1024 * 1024))  # 10 MB

# Parámetros de entrenamiento
SYMBOL="ETHUSDT"
HORIZON=4
UP_THR=0.5
DOWN_THR=0.5
C_REG=0.1
CANDLES=40000
VOL_HORIZON=4
RIDGE_ALPHA=1.0

# Archivos de pesos
CLASSIFIER_WEIGHTS="ml_weights_v2.json"
VOLATILITY_WEIGHTS="volatility_weights_ridge.json"

# Backup
BACKUP_DIR="ml_backups"
mkdir -p "$BACKUP_DIR"

# ================= FUNCIONES =================
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOGFILE"
}

rotate_log() {
    if [[ -f "$LOGFILE" && $(stat -c%s "$LOGFILE") -gt $MAX_LOG_SIZE ]]; then
        mv "$LOGFILE" "${LOGFILE}.$(date +%Y%m%d_%H%M%S).bak"
        log "Log rotado (tamaño > ${MAX_LOG_SIZE} bytes)"
    fi
}

check_lock() {
    if [[ -f "$LOCKFILE" ]]; then
        local pid
        pid=$(cat "$LOCKFILE")
        if kill -0 "$pid" 2>/dev/null; then
            log "ERROR: Ya hay un entrenamiento en ejecución (PID $pid). Saliendo."
            exit 1
        else
            log "Lockfile huérfano detectado, eliminando."
            rm -f "$LOCKFILE"
        fi
    fi
    echo $$ > "$LOCKFILE"
}

release_lock() {
    rm -f "$LOCKFILE"
}

backup_weights() {
    if [[ -f "$CLASSIFIER_WEIGHTS" ]]; then
        cp "$CLASSIFIER_WEIGHTS" "$BACKUP_DIR/${CLASSIFIER_WEIGHTS}.$(date +%Y%m%d_%H%M%S).bak"
        log "Backup del clasificador creado"
    fi
    if [[ -f "$VOLATILITY_WEIGHTS" ]]; then
        cp "$VOLATILITY_WEIGHTS" "$BACKUP_DIR/${VOLATILITY_WEIGHTS}.$(date +%Y%m%d_%H%M%S).bak"
        log "Backup del regresor de volatilidad creado"
    fi
    # Mantener solo los últimos 10 backups
    ls -1t "$BACKUP_DIR"/*.bak 2>/dev/null | tail -n +11 | xargs rm -f 2>/dev/null || true
}

train_classifier() {
    log "=== Iniciando entrenamiento del CLASIFICADOR ==="
    local output
    output=$(python3 train_ml_weights.py \
        --type classifier \
        --symbol "$SYMBOL" \
        --horizon "$HORIZON" \
        --up_thr "$UP_THR" \
        --down_thr "$DOWN_THR" \
        --c_reg "$C_REG" \
        --candles "$CANDLES" \
        --model logistic \
        --class_weight balanced 2>&1)
    local exit_code=$?
    echo "$output" >> "$LOGFILE"
    
    if [[ $exit_code -ne 0 ]]; then
        log "ERROR: Entrenamiento del clasificador falló (código $exit_code)"
        return 1
    fi
    
    # Extraer accuracy del log
    local acc
    acc=$(echo "$output" | grep -oP 'Accuracy en test: \K[0-9.]+' | head -1)
    if [[ -n "$acc" ]]; then
        log "Clasificador completado. Accuracy: $acc (${acc}%)"
        # Umbral mínimo 85% (igual que en Python)
        if (( $(echo "$acc < 0.85" | bc -l) )); then
            log "ADVERTENCIA: Accuracy ($acc) es inferior a 85%. El modelo NO fue guardado."
            # Restaurar backup si existe y el actual es malo
            local latest_backup
            latest_backup=$(ls -t "$BACKUP_DIR"/${CLASSIFIER_WEIGHTS}.*.bak 2>/dev/null | head -1)
            if [[ -f "$latest_backup" ]]; then
                cp "$latest_backup" "$CLASSIFIER_WEIGHTS"
                log "Restaurado clasificador desde backup: $latest_backup"
            fi
            return 1
        fi
    else
        log "No se pudo extraer accuracy del log"
    fi
    log "Clasificador guardado correctamente."
    return 0
}

train_volatility() {
    log "=== Iniciando entrenamiento del REGRESOR DE VOLATILIDAD (Ridge) ==="
    local output
    output=$(python3 train_volatility_ridge.py \
        --horizon "$VOL_HORIZON" \
        --alpha "$RIDGE_ALPHA" \
        --candles "$CANDLES" 2>&1)
    local exit_code=$?
    echo "$output" >> "$LOGFILE"
    
    if [[ $exit_code -ne 0 ]]; then
        log "ERROR: Entrenamiento del regresor falló (código $exit_code)"
        return 1
    fi
    
    # Extraer métricas
    local mae r2
    mae=$(echo "$output" | grep -oP 'MAE = \K[0-9.]+' | head -1)
    r2=$(echo "$output" | grep -oP 'R² = \K[0-9.]+' | head -1)
    log "Regresor completado. MAE=$mae, R²=$r2"
    
    if (( $(echo "$r2 < 0.4" | bc -l) )); then
        log "ADVERTENCIA: R² ($r2) es bajo (<0.4). El modelo puede no ser útil."
    fi
    return 0
}

send_alert() {
    local subject="$1"
    local body="$2"
    # Puedes enviar por Telegram, email, etc.
    # Ejemplo con Telegram (descomenta y configura)
    # local TG_BOT_TOKEN="tu_token"
    # local TG_CHAT_ID="tu_chat_id"
    # curl -s -X POST "https://api.telegram.org/bot$TG_BOT_TOKEN/sendMessage" \
    #     -d "chat_id=$TG_CHAT_ID" -d "text=$subject%0A$body" > /dev/null
    log "ALERTA: $subject - $body"
}

# ================= MAIN =================
rotate_log
check_lock
trap release_lock EXIT

log "=== INICIO DEL CICLO DE ENTRENAMIENTO ==="
backup_weights

# Entrenar clasificador
train_classifier
CLASSIFIER_OK=$?

# Entrenar regresor de volatilidad (opcional, comenta si no quieres)
train_volatility
VOL_OK=$?

# Resumen final
if [[ $CLASSIFIER_OK -eq 0 && $VOL_OK -eq 0 ]]; then
    log "Entrenamiento completo: ambos modelos actualizados correctamente."
else
    log "Entrenamiento parcial con errores. Clasificador: $CLASSIFIER_OK, Volatilidad: $VOL_OK"
    send_alert "ML Training Error" "Clasificador: $CLASSIFIER_OK, Volatilidad: $VOL_OK. Revisa $LOGFILE"
fi

log "=== FIN DEL CICLO DE ENTRENAMIENTO ==="
release_lock
exit 0